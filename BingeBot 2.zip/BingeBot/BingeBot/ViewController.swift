//
//  ViewController.swift
//  BingeBot
//
//  Created by Vincent E. Hunter (Student) on 1/15/19.
//  Copyright © 2019 Vincent E. Hunter (Student). All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var showsLabel: UILabel!
    @IBOutlet weak var randomShowLabel: UILabel!
    
    @IBOutlet weak var bingeBotSpoken: UILabel!
    
    @IBOutlet weak var addShowTextField: UITextField!
    @IBAction func addShow(_ sender: Any) {
    }
    @IBOutlet weak var randomShowStackView: UIStackView!
    @IBOutlet weak var addShowStackView: UIStackView!
    @IBOutlet weak var showStackView: UIStackView!
    
    var shows: [String] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        showStackView.isHidden = true
        randomShowStackView.isHidden = true
    }
    func updateShowsLabel()  {
        showsLabel.text = shows.joined(separator: ", ")
    }
    @IBAction func randomBingeShowButtonWasPressed(_ sender: Any) {
        
        let rando = Int(arc4random() %  UInt32(shows.count))
        randomShowLabel.text = "\(shows[rando])"
            
//        print(shows[randomShowLabel])

        randomShowLabel.isHidden = false
        bingeBotSpoken.isHidden = false
    }
    
    
    @IBAction func addShowButtonWasPressed(_ sender: Any) {
        guard let showName = addShowTextField.text else{
            return }
        shows.append(showName)
        updateShowsLabel()
        addShowTextField.text = ""
        showStackView.isHidden = false
        
        if shows.count > 1{
            randomShowStackView.isHidden = false
            bingeBotSpoken.isHidden = true
            randomShowLabel.isHidden = true
            
        } else if shows.count == 0 {
          randomShowLabel.isHidden = true
        bingeBotSpoken.isHidden = true
        
         
        }
        
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

